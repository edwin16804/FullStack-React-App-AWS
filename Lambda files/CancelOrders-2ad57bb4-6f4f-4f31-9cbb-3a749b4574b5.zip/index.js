const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const tableName = 'ShoeStoreOrders'; // Replace with your DynamoDB table name

exports.handler = async (event) => {
  // Log the event to help with debugging
  console.log("Received event:", JSON.stringify(event));

  // Extract orderId from path parameters
  const orderId = event.pathParameters ? event.pathParameters.orderId : null;
  
  // If orderId is not provided, return a 400 Bad Request response
  if (!orderId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ message: 'Order ID is required',orderId }),
    };
  }

  const params = {
    TableName: tableName,
    Key: {
      OrderId: orderId, // Ensure this matches the partition key in your DynamoDB table
    },
  };

  try {
    // Attempt to delete the order from DynamoDB
    await dynamoDB.delete(params).promise();

    // Return success response with CORS headers
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',  // Allow all origins
        'Access-Control-Allow-Credentials': true, // If you're using cookies or credentials
      },
      body: JSON.stringify({ message: 'Order deleted successfully' }),
    };
  } catch (error) {
    // Log the error and return an error response
    console.error("Error deleting order:", error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',  // Allow all origins
      },
      body: JSON.stringify({ message: 'Error deleting order', error: error.message }),
    };
  }
};
