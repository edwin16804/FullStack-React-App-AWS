const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = 'ShoeStoreOrders';

exports.handler = async (event) => {
  const orderId = event.pathParameters.orderId;
  const body = JSON.parse(event.body);

  // Validate required fields
  if (!orderId || !body.name || !body.phone) {
    return {
      statusCode: 400,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow all origins
        'Access-Control-Allow-Methods': 'OPTIONS, PUT',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify({ message: "Missing required fields" }),
    };
  }

  const { name, phone } = body;

  const params = {
    TableName: TABLE_NAME,
    Key: { OrderId: orderId },
    UpdateExpression: 'SET #name = :name, #phone = :phone',
    ExpressionAttributeNames: {
      '#name': 'name',
      '#phone': 'phone',
    },
    ExpressionAttributeValues: {
      ':name': name,
      ':phone': phone,
    },
    ReturnValues: 'ALL_NEW',
  };

  try {
    const result = await dynamoDB.update(params).promise();
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow all origins
        'Access-Control-Allow-Methods': 'OPTIONS, PUT',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify({
        message: 'Order updated successfully',
        updatedOrder: result.Attributes,
      }),
    };
  } catch (error) {
    console.error("Error updating order:", error);
    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*', // Allow all origins
        'Access-Control-Allow-Methods': 'OPTIONS, PUT',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
      body: JSON.stringify({ message: 'Failed to update order' }),
    };
  }
};
