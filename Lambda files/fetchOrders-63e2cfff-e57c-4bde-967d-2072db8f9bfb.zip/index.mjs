import AWS from 'aws-sdk';

const dynamoDB = new AWS.DynamoDB.DocumentClient();
const tableName = 'ShoeStoreOrders';

export const handler = async (event) => {
    // Set CORS headers
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
        'Content-Type': 'application/json'
    };

    try {
        const params = {
            TableName: tableName
        };

        const result = await dynamoDB.scan(params).promise();
        
        // Map the result to ensure the correct fields are returned
        const orders = result.Items.map(item => ({
            orderId: item.OrderId,  // Ensure correct field name
            phoneNumber: item.phone,
            name:item.name,
            shoe: item.shoe,
            quantity: item.quantity,
            totalPrice: item.totalPrice
        }));
        
        return {
            statusCode: 200,
            headers: headers,
            body: JSON.stringify(orders)
        };
        
    } catch (error) {
        console.error('Error:', error);
        
        return {
            statusCode: 500,
            headers: headers,
            body: JSON.stringify({ 
                message: 'Error fetching orders',
                error: error.message 
            })
        };
    }
};